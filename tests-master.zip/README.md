## Quick start

### Configure `npm`

Configure `npm` on your system if needed (can be installed from npmjs.org). The default .npmrc is included in this package

### Get the code

# install required packages via npm
npm install
```

### Running it locally

```bash
npm run build:dev
```

Then open one of the `demo.html` files in your browser.
