/* eslint-disable no-undef */
/* eslint-disable no-unused-vars */
function choosecolor() {
    var letters = '0123456789ABCDEF';
    var color = '#';
    for (var i = 0; i < 6; i++) {
      color += letters[Math.floor(Math.random() * 16)];
    }
    return color;
}

function coloMe() {
    document.getElementsByClassName('load-bar')[0].style.display='block';
    document.getElementsByClassName("dot1")[0].style.backgroundColor = choosecolor();
    document.getElementsByClassName("dot2")[0].style.backgroundColor = choosecolor();
    document.getElementsByClassName("dot3")[0].style.backgroundColor = choosecolor();
}


    