const tag = 'generate-circle';
const html = require('./generate-circle.html');
const css = require('./generate-circle.scss');

customElements.define(tag, class extends EDSElement {
    static get observedAttributes() {
        return ['load', 'motif'];
    }

    init() {
        this.initShadowDOM(tag, html, css);
        this.defineDefaultProperties(['motif']);
        this._refs = {
            load: this.$('.load-bar'),
      
        };
    }

    initShadowDOM(tag, html, css) {
        super.initShadowDOM(tag, html, css);
    }

    get load() {
        return this.getAttribute('load');
    }

    set load(value) {
        this.setAttribute('load', value);
        this._refs.load.style.width = value + '%';
    }

    

    connectedCallback() {
    }
    
});

