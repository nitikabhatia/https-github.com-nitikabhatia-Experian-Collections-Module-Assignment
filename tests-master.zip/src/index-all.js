require('./core');
require('./components/generate-circle/generate-circle');
